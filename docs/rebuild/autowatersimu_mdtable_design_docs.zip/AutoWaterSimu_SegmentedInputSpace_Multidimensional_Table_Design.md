# AutoWaterSimu 多分段工况输入空间多维表格设计文档

**文档版本**：v0.1  
**模块名称**：SegmentedInputSpace  
**中文名称**：多分段工况输入空间  
**适用项目**：AutoWaterSimu Next  
**关联模块**：ProcessGraph、SimulationInput、Simulation Worker、ODEResultSpace、Agent Scenario Draft  
**文档定位**：产品需求 + 交互规格 + 数据结构草案 + 实施路线

---

## 1. 背景与问题定义

AutoWaterSimu 的实际仿真需求并不是“填写一组固定参数后求解”这么简单。真实水处理过程往往包含多阶段、多对象、多变量、多来源的工况变化，例如：

```text
0-2h：正常进水，COD = 280 mg/L，流量 = 100 m³/h
2-6h：冲击负荷，COD = 450 mg/L，NH4-N = 40 mg/L，流量 = 120 m³/h
6-10h：恢复期，COD 逐步下降，流量降低到 80 m³/h
10-12h：曝气增强，DO setpoint 提高
```

这些变化不只作用于进水节点，还可能同时影响：

- 流程图节点：进水、反应池、沉淀池、出水、用户自定义模型节点。
- 流程图边：流量、回流比例、排泥、旁路、混合比例。
- 水质组分：COD、BOD、NH4-N、NO3-N、TN、TP、DO、SS 等。
- 模型参数：ASM1、ASM3、UDM、温度修正、动力学参数。
- 控制设定：曝气、回流、停运、检修、药剂投加等。
- 数据来源：默认值、模板、历史数据、手动输入、Agent 草案、导入文件。

因此，多分段输入的本质不是普通表单，而是：

```text
对象 × 参数 × 组分 × 时间段 × 来源 × 状态 × 校验 × 动作
```

这是一种多维数据空间。传统侧边栏表单、弹窗、节点配置页难以同时表达“对象、时间、变量、继承、覆盖、来源、校验、影响范围”这些关系。

本模块的目标是：用二维表格作为入口，但让用户能够自然编辑和理解背后的多维仿真输入空间。

---

## 2. 一句话定义

**SegmentedInputSpace = 以流程图对象为锚点、以时间段为组织轴、以单元格为输入入口、以继承覆盖为状态模型、以校验与影响预览为反馈机制的多分段仿真输入工作台。**

传统输入表格是：

```text
row × column → value
```

AutoWaterSimu 的多分段输入应升级为：

```text
process_object × variable × component × time_segment × source × state × validation × action → simulation_input
```

---

## 3. 产品目标与非目标

### 3.1 产品目标

1. **解决真实模拟场景的多分段输入难题**  
   支持用户在不同时间段配置不同进水、水质、流量、模型参数、控制设定。

2. **把流程图对象和输入条件联动起来**  
   用户点击流程图节点或边时，表格自动显示该对象在各时间段的输入。

3. **让用户清楚理解“哪些值来自默认，哪些值被覆盖”**  
   支持默认、继承、模板、导入、手动、Agent 草案等来源标识。

4. **把输入校验前置到编辑过程**  
   实时检测时间段重叠、缺口、单位错误、缺失值、越界、模型不兼容、拓扑不匹配等问题。

5. **生成标准化 SimulationInput**  
   表格不是 worker 直接输入，表格最终要生成已校验、已归一、已补全、单位统一的 `simulation_input.v1`。

6. **为 Agent 驱动仿真预留入口**  
   Agent 可以生成分段输入草案，但必须由用户审查、Go/Rust API 校验后才能提交计算。

### 3.2 非目标

1. 不在 P0 阶段实现完整 3D 数据空间。
2. 不让 Agent 直接生成 Python 代码或直接调用仿真核心。
3. 不让表格直接写入 worker 内部结构。
4. 不用一个超级大表承载所有对象、所有变量、所有时间点。
5. 不把前端 CanvasGraph 直接作为计算输入。

---

## 4. 用户角色

| 角色 | 主要关注点 | 典型操作 |
|---|---|---|
| 工艺工程师 | 真实工况、冲击负荷、流程对象输入 | 配置进水、水质、流量、曝气、回流等分段 |
| 模型工程师 | 模型参数、温度修正、参数校准 | 编辑 ASM/UDM 参数、设置参数分段、运行敏感性分析 |
| 运维/现场人员 | 现场数据导入、实际运行复盘 | 导入 CSV/Excel/历史数据，构建实际工况场景 |
| Agent 用户 | 用自然语言描述场景 | 让 Agent 生成分段输入草案，并在表格中审查 |
| 审查者 | 输入是否合理、是否可计算 | 查看校验、来源、覆盖、影响范围 |

---

## 5. 总体工作区设计

推荐采用四区联动布局：

```text
┌──────────────────────────────────────────────────────────────┐
│ 顶部：场景信息 / 时间轴 / 分段管理 / 模板 / 导入 / 校验摘要       │
├────────────────┬──────────────────────────────┬──────────────┤
│ 左侧流程图       │ 中间多分段输入表格              │ 右侧 Cell Portal │
│ Process Graph   │ Segmented Input Table         │ Input Inspector │
├────────────────┴──────────────────────────────┴──────────────┤
│ 底部：Validation Panel / Impact Preview / SimulationInput 摘要  │
└──────────────────────────────────────────────────────────────┘
```

### 5.1 顶部区域

包含：

- 场景名称、仿真总时长、起止时间、时间单位。
- 时间段可视化条。
- 新增时间段、拆分时间段、合并时间段、复制时间段。
- 工况模板：冲击负荷、低温、停运检修、曝气增强、回流调整等。
- 数据导入：CSV / Excel / JSON。
- 生成 SimulationInput。
- 校验状态摘要。

### 5.2 左侧流程图

职责：

- 展示流程拓扑。
- 高亮当前选中的节点/边。
- 按当前时间段显示输入热力状态。
- 点击节点/边过滤表格。
- 显示缺失输入、警告、错误状态。
- 显示影响路径。

### 5.3 中间表格

职责：

- 作为主要编辑区。
- 支持多种投影视图。
- 支持批量编辑、复制、继承、覆盖、模板应用。
- 显示单元格来源、状态、单位、校验标记。
- 支持虚拟滚动和冻结列/冻结时间段。

### 5.4 右侧 Cell Portal

职责：

- 展示当前输入单元格的完整上下文。
- 展示来源、继承、历史、校验、影响范围。
- 提供复制、恢复默认、标记事件、查看影响、应用到其他段等动作。

### 5.5 底部校验与预览区

职责：

- 显示全局校验问题。
- 显示当前编辑对流程图对象的影响。
- 显示转换后的 SimulationInput 摘要。
- 显示可提交/不可提交原因。

---

## 6. 核心视图设计

SegmentedInputSpace 不应该只提供一种表格，而应提供多个投影视图。所有视图共享同一份底层数据，只是观察维度不同。

---

### 6.1 视图 A：时间段 × 输入变量

**定位**：默认视图，最适合业务用户。  
**对象范围**：当前选中的节点 / 边 / 全局工况。  
**行**：时间段。  
**列**：输入变量。  
**单元格**：该时间段内该变量的输入值或输入模式。

示例：选中进水节点 `IN`

| 时间段 | 流量 m³/h | COD mg/L | NH4-N mg/L | TN mg/L | TP mg/L | 温度 ℃ | 输入来源 | 状态 |
|---|---:|---:|---:|---:|---:|---:|---|---|
| 0-2h | 100 | 280 | 32 | 45 | 4.2 | 20 | 默认 | 正常 |
| 2-6h | 120 | 450 | 40 | 60 | 5.1 | 20 | 冲击负荷模板 | 警告 |
| 6-10h | 80 | 260 | 28 | 42 | 4.0 | 19 | 历史导入 | 正常 |
| 10-12h | 90 | 270 | 30 | 44 | 4.1 | 19 | 手动 | 正常 |

适合回答：

- 每个时间段的输入条件是什么？
- 哪个时间段发生了冲击负荷？
- 哪个值来自模板，哪个值来自手动输入？
- 是否有漏填、越界或单位错误？

---

### 6.2 视图 B：流程对象 × 时间段

**定位**：最适合流程图联动。  
**行**：流程图对象，包括节点和边。  
**列**：时间段。  
**单元格**：该对象在该时间段是否有覆盖输入。

示例：

| 对象 | 类型 | 0-2h | 2-6h | 6-10h | 10-12h |
|---|---|---|---|---|---|
| IN | 进水节点 | 默认进水 | 冲击负荷 | 历史导入 | 默认进水 |
| R1 | ASM1 反应池 | 默认参数 | 默认参数 | DO 提高 | DO 提高 |
| R2 | ASM3 反应池 | 默认参数 | 温度修正 | 温度修正 | 默认参数 |
| E_IN_R1 | 边/流量 | 100m³/h | 120m³/h | 80m³/h | 90m³/h |
| RECYCLE | 回流边 | 30% | 30% | 40% | 40% |

适合回答：

- 哪些对象在某个时间段发生了变化？
- 哪些节点/边有覆盖输入？
- 某个时间段是否所有必要对象都已配置？
- 某个对象是否长期继承默认值？

---

### 6.3 视图 C：组分 × 时间段

**定位**：最适合水质输入。  
**对象范围**：当前进水、当前节点或当前边。  
**行**：水质组分。  
**列**：时间段。  
**单元格**：该组分在该时间段的输入。

示例：进水组分输入

| 组分 | 单位 | 0-2h | 2-6h | 6-10h | 10-12h | 默认值 | 状态 |
|---|---|---:|---:|---:|---:|---:|---|
| COD | mg/L | 280 | 450 | 260 | 270 | 280 | 警告 |
| NH4-N | mg/L | 32 | 40 | 28 | 30 | 32 | 正常 |
| TN | mg/L | 45 | 60 | 42 | 44 | 45 | 正常 |
| TP | mg/L | 4.2 | 5.1 | 4.0 | 4.1 | 4.2 | 正常 |
| DO | mg/L | 0.5 | 0.4 | 0.6 | 0.5 | 0.5 | 正常 |

适合回答：

- 冲击负荷改变了哪些组分？
- 某个组分是否随时间线性恢复？
- 某组分是否超出推荐范围？
- 组分单位和 component schema 是否一致？

---

### 6.4 视图 D：模型参数 × 时间段

**定位**：模型工程师视图。  
**对象范围**：当前节点绑定的 ASM / UDM / Material Balance 模型。  
**行**：模型参数。  
**列**：时间段。  
**单元格**：该参数在该时间段的值、覆盖或修正。

示例：R1 节点的 ASM1 参数

| 参数 | 含义 | 0-2h | 2-6h | 6-10h | 10-12h | 来源 |
|---|---|---:|---:|---:|---:|---|
| μ_H | 异养菌最大生长速率 | 默认 | 默认 | 默认 | 默认 | 参数集 |
| K_S | 底物半饱和系数 | 默认 | 默认 | 默认 | 默认 | 参数集 |
| K_OH | 氧半饱和系数 | 默认 | 默认 | 调整 | 调整 | 手动 |
| b_H | 衰减系数 | 默认 | 默认 | 默认 | 默认 | 参数集 |

适合：

- 参数校准。
- 温度修正。
- UDM 参数分段。
- 敏感性分析。
- 参数覆盖审查。

---

### 6.5 视图 E：模板与事件视图

**定位**：快速创建场景。  
**行**：工况事件或模板。  
**列**：作用时间、作用对象、变量、幅度、状态。

示例：

| 事件 | 时间 | 对象 | 变量 | 变化 | 状态 |
|---|---|---|---|---|---|
| COD 冲击负荷 | 2-6h | IN | COD | 280 → 450 mg/L | 已应用 |
| 低温工况 | 6-10h | 全局 | temperature | 20 → 12 ℃ | 草案 |
| 回流提高 | 6-12h | RECYCLE | recycle_ratio | 30% → 40% | 已应用 |
| 曝气增强 | 10-12h | R1 | DO setpoint | 1.5 → 2.0 | 已应用 |

---

## 7. Cell Portal：输入单元格解释入口

单元格不只是一个输入框，而是一个可解释入口。

### 7.1 Cell Portal 信息结构

```text
Input Cell Portal
├── 当前值
├── 单位与输入模式
├── 来源
├── 继承路径
├── 历史变更
├── 校验状态
├── 影响范围
├── 关联流程对象
├── 可执行动作
└── Agent / 模板解释
```

### 7.2 示例：点击 `IN / COD / 2-6h = 450 mg/L`

展示：

```text
当前值：
COD = 450 mg/L

输入模式：
hold，分段常量

来源：
冲击负荷模板，由用户在 2026-05-24 14:20 应用

继承关系：
覆盖项目默认进水 COD = 280 mg/L
仅作用于 2-6h

校验状态：
高于常规范围，但未超出冲击负荷允许范围
建议标记为 shock_load event

影响范围：
IN → R1 → R2 → OUT
预计影响 COD、DO、NH4-N 转化

可执行动作：
- 复制到下一时间段
- 转换为线性恢复
- 恢复默认值
- 查看预计影响
- 标记为冲击负荷事件
- 应用到所有同类节点
```

---

## 8. 继承与覆盖模型

多分段输入不能要求用户在每个时间段、每个对象、每个变量上重复填写。必须支持继承。

### 8.1 推荐继承顺序

```text
模型默认值
  ↓
项目默认参数
  ↓
流程图对象默认值
  ↓
场景默认值
  ↓
时间段覆盖
  ↓
单元格手动覆盖
```

### 8.2 来源标签

| 标签 | 含义 |
|---|---|
| 默认 | 来自模型或项目默认值 |
| 继承 | 当前段未显式填写，继承上层值 |
| 模板 | 来自工况模板 |
| 导入 | 来自 CSV / Excel / historian 数据 |
| 手动 | 用户手动填写 |
| Agent 草案 | Agent 生成但未确认 |
| 冲突 | 多个来源冲突 |
| 锁定 | 不允许编辑 |

### 8.3 显示方式

每个单元格应显示：

- 主值。
- 单位。
- 来源角标。
- 状态角标。
- 警告/错误提示。
- 是否覆盖默认值。
- 是否可编辑。

示例：

```text
450 mg/L [模板] [警告]
继承 [默认]
40% [手动]
```

---

## 9. 支持的输入模式

每个单元格不应只支持一个数字，而应支持不同输入模式。

| 模式 | 说明 | 示例 |
|---|---|---|
| hold | 分段常量 | 2-6h COD = 450 |
| linear | 线性变化 | 6-10h COD 从 450 降到 280 |
| ramp | 斜坡变化 | 曝气逐步提高 |
| pulse | 脉冲 | 30 分钟冲击负荷 |
| schedule | 调度表 | 每小时流量不同 |
| event | 事件触发 | 3h 时回流比例切换 |
| imported_series | 外部时间序列 | CSV / historian 数据 |
| formula | 公式生成 | 温度修正、周期变化 |

### 9.1 ValueSpec 草案

```ts
type ValueSpec =
  | { mode: "hold"; value: number; unit: string }
  | { mode: "linear"; from: number; to: number; unit: string }
  | { mode: "ramp"; start: number; end: number; ramp_type: "linear" | "smooth"; unit: string }
  | { mode: "pulse"; value: number; duration: number; unit: string }
  | { mode: "schedule"; points: Array<{ t: number; value: number }>; unit: string }
  | { mode: "event"; event_key: string; value: number; unit: string }
  | { mode: "imported_series"; series_ref: string; unit: string }
  | { mode: "formula"; expression_id: string; unit: string };
```

---

## 10. 校验体系

### 10.1 时间轴校验

| 规则 | 说明 |
|---|---|
| 覆盖完整性 | 时间段是否覆盖总仿真时长 |
| 缺口 | 是否存在未定义时间段 |
| 重叠 | 是否有两个时间段重叠 |
| 边界合法 | start < end |
| 过短时间段 | 是否小于 solver 最小建议步长 |
| 过多分段 | 是否导致求解成本过高 |

### 10.2 单元格校验

| 规则 | 说明 |
|---|---|
| 必填 | 必要输入是否为空 |
| 单位 | 单位是否与变量语义匹配 |
| 范围 | 是否超出推荐范围或硬限制 |
| 模式 | 输入模式是否支持该变量 |
| 来源 | 来源是否可信或已确认 |
| 覆盖 | 是否覆盖锁定参数 |
| 精度 | 数值精度是否满足要求 |

### 10.3 对象级校验

| 对象 | 校验 |
|---|---|
| 节点 | 必要水质组分、体积、模型参数是否完整 |
| 边 | 流量、方向、连接对象是否合法 |
| 模型节点 | 参数集与模型类型是否匹配 |
| 进水节点 | 输入组分 schema 是否完整 |
| 出水节点 | 是否错误配置了不应输入的变量 |

### 10.4 全局仿真校验

| 规则 | 说明 |
|---|---|
| 组分一致性 | 所有节点使用的 component schema 是否兼容 |
| 单位归一 | 所有值是否可转换到标准单位 |
| 拓扑连通 | 流程图是否存在断裂、孤立节点、非法环路 |
| 流量闭合 | 关键节点的进出流量是否明显异常 |
| 参数完整 | 模型绑定是否缺少必需参数 |
| Solver 适配 | 分段、步长、输入模式是否适配 ODE 求解 |

---

## 11. 与流程图的联动

### 11.1 点击流程图节点

系统行为：

```text
1. 表格切换到该节点。
2. 默认打开“时间段 × 输入变量”视图。
3. 节点在流程图中高亮。
4. 底部显示该节点输入完整性。
```

### 11.2 点击流程图边

系统行为：

```text
1. 表格切换到该边。
2. 显示流量、比例、传递参数、回流设定等。
3. 高亮上下游节点。
```

### 11.3 点击时间段

系统行为：

```text
1. 流程图显示该时间段工况热力。
2. 表格过滤到该时间段。
3. Validation Panel 显示该段问题。
```

### 11.4 编辑表格单元格

系统行为：

```text
1. 流程图高亮影响路径。
2. Validation Panel 重新计算。
3. Cell Portal 更新继承和来源。
4. 如果是关键输入，触发“预计影响”预览。
```

---

## 12. 工况模板

### 12.1 模板类型

| 模板 | 说明 |
|---|---|
| 持续进水 | 常规基线输入 |
| 冲击负荷 | 某组分在指定时段升高 |
| 低温工况 | 温度下降并触发参数修正 |
| 高流量工况 | 进水流量升高 |
| 停运检修 | 某节点或边停止运行 |
| 曝气增强 | DO setpoint 提高 |
| 回流调整 | 回流比例变化 |
| 药剂调整 | 药剂投加或水质参数变化 |
| 雨季稀释 | 浓度下降、流量上升 |
| 夜间低负荷 | 流量下降、负荷降低 |

### 12.2 模板应用流程

```text
选择模板
  ↓
填写作用时间和作用对象
  ↓
预览将要创建的时间段和赋值
  ↓
用户确认
  ↓
生成 segments + assignments
  ↓
表格显示模板来源
  ↓
重新校验
```

---

## 13. Agent 草案输入

Agent 可以根据自然语言生成分段输入草案，但不能直接提交计算。

### 13.1 示例

用户输入：

```text
模拟一个 2 小时 COD 冲击负荷，发生在第 3 小时，COD 从 280 升到 500，随后 4 小时逐渐恢复。
```

Agent 生成草案：

```json
{
  "draft_version": "agent-segmented-input-draft.v1",
  "segments": [
    { "label": "baseline", "start": 0, "end": 3 },
    { "label": "COD shock", "start": 3, "end": 5 },
    { "label": "recovery", "start": 5, "end": 9 }
  ],
  "assignments": [
    {
      "target": { "object_type": "node", "object_id": "IN" },
      "variable": { "component_key": "COD", "unit": "mg/L" },
      "segment": "COD shock",
      "value_spec": { "mode": "hold", "value": 500 }
    },
    {
      "target": { "object_type": "node", "object_id": "IN" },
      "variable": { "component_key": "COD", "unit": "mg/L" },
      "segment": "recovery",
      "value_spec": { "mode": "linear", "from": 500, "to": 280 }
    }
  ],
  "explanation": "用户希望模拟第 3 小时开始的 COD 冲击负荷，并在后续 4 小时恢复。"
}
```

### 13.2 安全边界

- Agent 只能生成草案。
- 草案必须显示在表格中。
- 用户必须确认。
- 后端必须校验。
- 通过后才能生成 SimulationInput。
- Agent 不直接生成 Python、Rust、Go 代码。

---

## 14. 数据模型草案

### 14.1 SegmentedScenarioInput

```ts
type SegmentedScenarioInput = {
  schema_version: "segmented-scenario-input.v1";

  scenario_id: string;
  scenario_name: string;
  process_graph_id: string;
  base_parameter_set_id?: string;

  time_axis: {
    start_time: string;
    end_time: string;
    base_unit: "h" | "min";
    solver_step_hint?: number;
  };

  segments: TimeSegment[];
  assignments: SegmentAssignment[];

  validation: ValidationSummary;

  provenance: {
    created_by: string;
    created_at: string;
    source: "manual" | "template" | "import" | "agent";
  };
};
```

### 14.2 TimeSegment

```ts
type TimeSegment = {
  segment_id: string;
  label: string;
  start: number;
  end: number;
  unit: "h" | "min";
  segment_type:
    | "normal"
    | "shock_load"
    | "maintenance"
    | "low_temperature"
    | "aeration_adjustment"
    | "recycle_adjustment"
    | "custom";
  color?: string;
  priority?: number;
  locked?: boolean;
};
```

### 14.3 SegmentAssignment

```ts
type SegmentAssignment = {
  assignment_id: string;

  target: {
    object_type: "node" | "edge" | "global" | "model_parameter";
    object_id: string;
  };

  variable: {
    variable_key: string;
    component_key?: string;
    semantic_type:
      | "flow_rate"
      | "concentration"
      | "volume"
      | "temperature"
      | "model_parameter"
      | "control_setpoint"
      | "recycle_ratio"
      | "dosing_rate";
    unit: string;
  };

  segment_id: string;
  value_spec: ValueSpec;

  source: {
    source_type: "default" | "manual" | "template" | "import" | "agent";
    source_ref?: string;
  };

  inheritance?: {
    inherited_from?: "model_default" | "project_default" | "object_default" | "scenario_default" | "previous_segment";
    overridden: boolean;
    original_value?: unknown;
  };

  state: "draft" | "valid" | "warning" | "invalid" | "locked";
};
```

### 14.4 SimulationInput 生成

`SegmentedScenarioInput` 不直接进入 worker，而是经过转换：

```text
SegmentedScenarioInput
  ↓ validate
  ↓ normalize units
  ↓ resolve inheritance
  ↓ expand value specs
  ↓ align with solver time grid
  ↓ compile to tensors / time functions
SimulationInput
```

---

## 15. 组件拆分

```text
SegmentedInputSpace
├── ScenarioHeader
├── TimeSegmentManager
│   ├── SegmentTimeline
│   ├── SegmentEditor
│   ├── SplitMergeControls
│   └── TemplateApplyDialog
│
├── ProcessGraphInputOverlay
│   ├── NodeInputStatusLayer
│   ├── EdgeInputStatusLayer
│   └── ImpactPathPreview
│
├── SegmentedInputTable
│   ├── TableToolbar
│   ├── ViewModeSwitcher
│   ├── TimeVariableView
│   ├── ObjectSegmentView
│   ├── ComponentSegmentView
│   ├── ParameterSegmentView
│   └── CellRenderer
│
├── InputCellPortal
│   ├── CurrentValuePanel
│   ├── SourcePanel
│   ├── InheritancePanel
│   ├── ValidationPanel
│   ├── ImpactPanel
│   └── ActionPanel
│
├── InputValidationPanel
├── SimulationInputPreview
└── AgentDraftReviewPanel
```

---

## 16. 状态与视觉规则

### 16.1 单元格状态

| 状态 | 视觉建议 |
|---|---|
| 默认 | 浅灰角标 |
| 继承 | 虚线边框 |
| 手动 | 蓝色角标 |
| 模板 | 紫色角标 |
| 导入 | 绿色角标 |
| Agent 草案 | 青色角标 + 未确认标识 |
| 警告 | 黄色边框 |
| 错误 | 红色边框 |
| 锁定 | 灰色底纹 + 锁图标 |
| 冲突 | 红黄双标识 |

### 16.2 流程图状态

| 状态 | 视觉建议 |
|---|---|
| 输入完整 | 绿色节点边框 |
| 有警告 | 黄色节点边框 |
| 有错误 | 红色节点边框 |
| 被当前表格过滤 | 蓝色高亮 |
| 受当前单元格影响 | 动态流向线 |
| 未配置必要输入 | 红色角标 |

---

## 17. 关键交互动作

| 动作 | 说明 |
|---|---|
| 新增时间段 | 在时间轴上添加一段 |
| 拆分时间段 | 将一个段拆成两个段 |
| 合并时间段 | 合并相邻兼容段 |
| 复制段配置 | 复制一个时间段的所有赋值 |
| 应用模板 | 根据模板生成 segments + assignments |
| 恢复默认 | 删除单元格覆盖 |
| 转换为线性变化 | 将 hold 转为 linear |
| 导入序列 | 从 CSV/Excel 导入 imported_series |
| 批量填充 | 对多个时间段或变量批量赋值 |
| 影响预览 | 高亮受该输入影响的流程路径 |
| 生成 SimulationInput | 触发全局校验并生成 worker 输入 |
| 提交仿真 | 创建 compute job |

---

## 18. 与 ODEResultSpace 的关系

SegmentedInputSpace 是仿真前输入空间，ODEResultSpace 是仿真后结果空间。

```text
SegmentedInputSpace
  ↓ 生成 SimulationInput
Simulation Worker
  ↓ 生成 ComputeResult
ODEResultSpace
```

两者应共享：

- ProcessGraph 对象索引。
- Component Schema。
- Time Axis。
- Scenario ID。
- Model Run ID。
- Artifact 引用。
- Cell Portal 思想。
- Row Object / Column Axis / Data Space Map 交互模型。

最终用户应形成稳定认知：

```text
用多维表格编辑输入；
用多维表格理解结果。
```

---

## 19. MVP 实施路线

### P0：解决核心录入问题

| 功能 | 验收标准 |
|---|---|
| 时间段管理器 | 可创建、编辑、拆分、合并时间段 |
| 时间段 × 输入变量表 | 可对当前节点/边编辑多段输入 |
| 来源与状态标签 | 默认、继承、手动、模板、导入可区分 |
| 基础校验 | 可检测重叠、缺口、必填、单位、越界 |
| 流程图联动 | 点击节点/边可过滤表格 |
| 生成 SimulationInput | 可生成标准 JSON 并提交 worker |

### P1：增强实际项目可用性

| 功能 | 验收标准 |
|---|---|
| Cell Portal | 可查看来源、继承、校验、影响范围 |
| 组分 × 时间段视图 | 可集中编辑水质组分 |
| 对象 × 时间段视图 | 可查看全流程对象变化 |
| 工况模板 | 支持冲击负荷、低温、回流调整等 |
| CSV/Excel 导入 | 可导入时间序列并映射变量 |
| 影响路径预览 | 编辑单元格后流程图高亮影响路径 |

### P2：高级输入能力

| 功能 | 验收标准 |
|---|---|
| Agent 草案 | Agent 可生成可审查的分段输入草案 |
| 输入事件回放 | 可回放输入是如何被创建和修改的 |
| 多方案输入对比 | 可对比 baseline 和 scenario |
| 参数敏感性输入 | 可为 sweep/calibration 生成输入空间 |
| Data Space Map | 可查看输入空间完整维度关系 |

---

## 20. 验收标准

P0 完成时，系统应满足：

1. 用户可以为一个流程图创建完整多分段输入。
2. 用户可以在不同视图下编辑进水、组分、边流量、节点参数。
3. 用户可以区分默认、继承、模板、导入、手动输入。
4. 系统可以检测时间段缺口、重叠、单位错误、必填缺失、值越界。
5. 点击流程图节点/边可以联动表格。
6. 点击表格单元格可以看到基本来源和校验信息。
7. 系统可以生成标准化 `simulation_input.v1`。
8. `simulation_input.v1` 可以提交给 worker 并产生 job。
9. 错误输入不能提交，警告输入需要用户确认。
10. 所有关键操作应有事件记录。

---

## 21. 主要风险与应对

| 风险 | 说明 | 应对 |
|---|---|---|
| 表格过大 | 对象 × 时间段 × 变量过多 | 多投影视图 + 虚拟滚动 + 过滤 |
| 用户迷失 | 多维交互复杂 | 保留流程图、时间轴、表格三重锚点 |
| 输入模式过多 | hold/linear/series 等复杂 | P0 仅支持 hold/linear/imported_series |
| 校验复杂 | 模型和拓扑规则多 | 分层校验：cell/object/global/model |
| Agent 生成错误 | 自然语言可能歧义 | Agent 只生成草案，必须用户确认 |
| 单位混乱 | mg/L、kg/d、m³/h 混用 | 强制 Unit Registry 与标准单位 |
| 结果不可追溯 | 不知道输入来自哪里 | source + inheritance + event log |

---

## 22. 最终产品判断

SegmentedInputSpace 不应该被定义为“一个复杂输入表”，而应该被定义为：

```text
AutoWaterSimu 的多分段仿真输入数据空间。
```

它的价值是：

- 把时间分段、流程对象、水质组分、模型参数组织到一个统一界面。
- 把默认、继承、模板、导入、手动输入变成可见状态。
- 把输入校验和影响预览前置。
- 把自然语言 Agent 草案变成可审查的结构化输入。
- 为后续 ODE 求解结果分析提供同构的数据空间基础。

一句话总结：

> **AutoWaterSimu 的多分段输入不是表单输入，而是时间化、对象化、来源化、可校验的仿真输入数据空间。**
