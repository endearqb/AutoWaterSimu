# AutoWaterSimu ODE 求解结果 + 流程图联合分析多维表格设计文档

**文档版本**：v0.1  
**模块名称**：ODEResultSpace  
**中文名称**：ODE 求解结果数据空间  
**适用项目**：AutoWaterSimu Next  
**关联模块**：ProcessGraph、SegmentedInputSpace、Simulation Worker、ComputeResult、ModelRun、Agent Insight  
**文档定位**：产品需求 + 交互规格 + 数据结构草案 + 实施路线

---

## 1. 背景与问题定义

AutoWaterSimu 的 ODE 求解结果不是普通的二维数据。一次仿真可能产生：

- 多个流程图节点的时间序列。
- 多条边的流量、负荷、传递参数。
- 多个水质组分的浓度变化。
- 多个模型节点的状态变量。
- 多个时间段的事件与参数变化。
- 质量守恒、体积守恒、收敛、误差、警告。
- 多个方案之间的对比。
- 模型版本、参数集、输入 hash、结果 artifact 等证据。

这些数据天然具有以下多维结构：

```text
节点 / 边 × 组分 × 时间 × 模型 × 参数 × 工况 × 场景 × 状态 × 流程关系
```

如果只用普通曲线图，用户难以定位局部异常。  
如果只用普通结果表，用户难以理解时间趋势和流程传播。  
如果只用流程图，用户难以查看高密度数值。

因此，AutoWaterSimu 需要一个联合工作台：

```text
流程图负责拓扑关系
多维表格负责数值定位
曲线图负责趋势理解
Cell Portal 负责局部解释
Data Space Map 负责全局关系
```

---

## 2. 一句话定义

**ODEResultSpace = 以流程图为拓扑入口、以二维表格为数值锚点、以时间轴为动态控制、以单元格为解释入口、以模型运行证据为可信基础的 ODE 求解结果多维分析工作台。**

传统结果表格是：

```text
row × column → value
```

AutoWaterSimu 的 ODE 结果分析应升级为：

```text
process_object × component × time × edge_relation × scenario × model_run × quality × action → analytical_view
```

---

## 3. 产品目标与非目标

### 3.1 产品目标

1. **把 ODE 结果从“曲线文件”升级为可交互的数据空间**。
2. **把流程图拓扑与节点/边结果强绑定**。
3. **支持用户从一个单元格进入来源、历史、上下游关系、质量状态和动作**。
4. **支持按节点、边、组分、时间、场景、模型运行等维度切片分析**。
5. **支持质量守恒、体积守恒、收敛和异常诊断**。
6. **支持未来 Agent 基于结构化上下文解释结果**。
7. **支持生成可进入 NewSystem 审批或报告的模型运行证据**。

### 3.2 非目标

1. 不在 P0 阶段做完整 3D 数据立方体。
2. 不用一个巨大表格展示所有时间点和所有组分。
3. 不让 Agent 根据原始 JSON 自由猜测原因。
4. 不把所有大结果直接存入数据库。
5. 不用流程图替代表格，不用表格替代曲线。

---

## 4. 总体工作区设计

推荐采用四区联动布局：

```text
┌──────────────────────────────────────────────────────────────┐
│ 顶部：Job / Scenario / ModelRun / Time Slider / Scenario Switch │
├────────────────┬──────────────────────────────┬──────────────┤
│ 左侧流程图       │ 中间 ODE Result Table          │ 右侧 Cell Portal │
│ Graph Overlay   │ Multidimensional Table        │ Result Inspector │
├────────────────┴──────────────────────────────┴──────────────┤
│ 底部：趋势图 / 质量诊断 / 事件回放 / Artifact / Agent Insight     │
└──────────────────────────────────────────────────────────────┘
```

### 4.1 顶部区域

包含：

- job_id、scenario_id、model_run_id。
- 求解状态、求解器、模型版本、参数集。
- 时间滑块。
- 场景切换：baseline / plan A / plan B。
- 组分选择器。
- 质量状态摘要。
- 导出与报告按钮。

### 4.2 左侧流程图

职责：

- 展示流程拓扑。
- 按当前时间和当前组分显示热力图。
- 高亮当前选中节点/边。
- 高亮上下游路径。
- 标记异常节点、质量误差、收敛问题。
- 支持点击节点/边联动表格。

### 4.3 中间多维结果表格

职责：

- 展示当前投影的数值结果。
- 支持多种视图：节点×组分、时间×组分、边×负荷、场景对比、质量诊断。
- 支持单元格点击进入 Cell Portal。
- 支持列作为观察轴。
- 支持虚拟滚动、冻结列、时间切片。

### 4.4 右侧 Cell Portal

职责：

- 展示单元格当前值。
- 展示时间、对象、组分、单位、模型来源。
- 展示历史趋势、上下游关系、质量状态。
- 展示相关曲线、相关事件、可执行动作。
- 为 Agent 解释提供结构化上下文。

### 4.5 底部区域

包含：

- 趋势图。
- 质量诊断。
- 仿真事件回放。
- artifact 列表。
- Agent insight。
- 导出证据。

---

## 5. 核心维度

ODEResultSpace 至少应支持以下维度：

| 维度 | 含义 | 示例 |
|---|---|---|
| Node | 流程图节点 | IN、R1、R2、OUT |
| Edge | 流程图边 | E_IN_R1、RECYCLE |
| Component | 水质组分或状态变量 | COD、NH4-N、NO3-N、DO、SS |
| Time | 求解时间轴 | 0h、1h、2h、... |
| Metric | 派生指标 | mass_error、volume_error、load、removal_rate |
| Scenario | 仿真方案 | baseline、shock_load、plan_A |
| Model | 模型类型 | material_balance、ASM1、ASM3、UDM |
| ParameterSet | 参数集 | default、calibrated、temperature_corrected |
| Quality | 质量状态 | converged、warning、failed |
| Artifact | 结果文件 | result.json、timeseries.csv、chart.png |
| Event | 求解过程事件 | segment_entered、warning_emitted、solve_completed |

---

## 6. 核心视图设计

### 6.1 视图 A：Node × Component 当前时间切片

**定位**：默认结果视图。  
**行**：节点。  
**列**：组分。  
**时间**：由 Time Slider 控制。  
**单元格**：当前时间点该节点该组分的值。

示例：

| Node | Type | COD | NH4-N | NO3-N | DO | SS | Mass Error | Status |
|---|---|---:|---:|---:|---:|---:|---:|---|
| IN | influent | 280 | 35 | 1.2 | 0.5 | 120 | - | 输入 |
| R1 | ASM1 | 120 | 18 | 4.1 | 1.8 | 80 | 0.001% | 正常 |
| R2 | ASM3 | 60 | 6.8 | 11.2 | 2.1 | 45 | 0.003% | 警告 |
| OUT | effluent | 28 | 1.1 | 13.6 | 4.0 | 12 | - | 达标 |

适合回答：

- 当前时间点各节点水质状态如何？
- 哪些节点异常？
- 某个组分沿流程图如何变化？
- 出水是否达标？

---

### 6.2 视图 B：Time × Component 单节点展开

**定位**：节点详情视图。  
**对象范围**：当前选中节点。  
**行**：时间。  
**列**：组分。  
**单元格**：该时间点该组分的值。

示例：R2 节点

| Time | COD | NH4-N | NO3-N | DO | Volume | Status |
|---|---:|---:|---:|---:|---:|---|
| 0h | 280 | 35 | 1.2 | 0.5 | 500 | 初始 |
| 1h | 240 | 31 | 2.4 | 0.8 | 502 | 正常 |
| 2h | 210 | 26 | 3.9 | 1.1 | 505 | 正常 |
| 8h | 60 | 6.8 | 11.2 | 2.1 | 510 | NH4 警告 |

适合回答：

- 某个节点内部状态如何随时间变化？
- 是否存在突变？
- 哪个时间点出现异常？
- 参数变化是否导致趋势变化？

---

### 6.3 视图 C：Edge × Flow / Load 视图

**定位**：传递关系分析。  
**行**：边。  
**列**：流量、负荷、上游浓度、下游浓度、传递量、状态。

示例：

| Edge | From → To | Flow m³/h | COD Load kg/h | NH4 Load kg/h | Source | Status |
|---|---|---:|---:|---:|---|---|
| E_IN_R1 | IN → R1 | 120 | 54.0 | 4.8 | input segment | 正常 |
| E_R1_R2 | R1 → R2 | 118 | 14.2 | 2.1 | simulation | 正常 |
| RECYCLE | R2 → R1 | 40 | 2.4 | 0.3 | recycle setting | 警告 |

适合回答：

- 污染负荷从哪里来？
- 哪条边导致下游异常？
- 回流对节点状态影响多大？
- 流量是否与分段输入一致？

---

### 6.4 视图 D：Scenario Comparison 多方案对比

**定位**：方案比较。  
**行**：对象或指标。  
**列**：baseline / scenario A / scenario B / delta。  
**单元格**：方案结果或差值。

示例：

| Object | Metric | Baseline | Plan A | Plan B | ΔA | ΔB |
|---|---|---:|---:|---:|---:|---:|
| OUT | NH4-N | 2.1 | 1.3 | 1.8 | -0.8 | -0.3 |
| OUT | COD | 35 | 28 | 31 | -7 | -4 |
| R2 | DO | 1.2 | 2.0 | 1.7 | +0.8 | +0.5 |
| System | Mass Error | 0.004% | 0.006% | 0.005% | +0.002% | +0.001% |

适合回答：

- 哪个方案更好？
- 优化方案是否改善出水？
- 保守方案和激进方案的风险差异是什么？
- milp 方案经过工艺仿真后是否可接受？

---

### 6.5 视图 E：Mass Balance / Quality Diagnostics

**定位**：模型质量与数值可信度分析。  
**行**：节点、时间段或系统级指标。  
**列**：质量守恒、体积守恒、收敛、错误、诊断。

示例：

| Object | Time Window | Mass Error | Volume Error | Solver Status | Diagnosis |
|---|---|---:|---:|---|---|
| R1 | 0-12h | 0.002% | 0.001% | converged | 正常 |
| R2 | 6-8h | 0.15% | 0.04% | warning | 参数变化导致短时误差 |
| OUT | 0-12h | - | - | normal | 出水达标 |
| System | full | 0.006% | 0.003% | converged | 可接受 |

适合回答：

- 结果是否可信？
- 是否存在数值发散？
- 哪个时间段误差最大？
- 是否可以作为审批证据？

---

### 6.6 视图 F：Model Run Evidence 证据视图

**定位**：审计、报告、Agent 解释。  
**行**：模型运行或结果 artifact。  
**列**：模型版本、输入 hash、参数 hash、结果 hash、质量、artifact。

示例：

| Model Run | Job Type | Model | Version | Input Hash | Parameter Hash | Status | Artifact |
|---|---|---|---|---|---|---|---|
| run_001 | simulation.material_balance.v1 | material_balance | v1 | abc123 | p001 | succeeded | result.json |
| run_002 | simulation.asm1.v1 | ASM1 | v1 | def456 | p002 | warning | timeseries.csv |

适合回答：

- 这个结果来自哪次模型运行？
- 输入和参数是否可追溯？
- 结果 artifact 在哪里？
- Agent 解释依据是什么？

---

## 7. Cell Portal：结果单元格解释入口

### 7.1 Cell Portal 信息结构

```text
Result Cell Portal
├── 当前值
├── 单位与语义
├── 时间点
├── 所属节点/边
├── 模型来源
├── 历史趋势
├── 上下游关系
├── 质量状态
├── 相关事件
├── 相关曲线
├── 证据引用
└── 可执行动作
```

### 7.2 示例：点击 `R2 / NH4-N / 8h = 6.8 mg/L`

展示：

```text
当前值：
NH4-N = 6.8 mg/L

状态：
高于目标阈值，警告

所属对象：
R2 反应池，模型 ASM3

时间点：
8h

上游输入：
R1 出水、RECYCLE 回流边

相关边：
E_R1_R2 flow = 118 m³/h
RECYCLE ratio = 40%

历史趋势：
4h 到 8h 持续升高

相关组分：
DO 偏低，COD 下降较慢

质量状态：
质量守恒误差正常，说明不是数值发散

来源：
simulation.asm3.v1 / model_run_002

可执行动作：
- 高亮上游路径
- 查看 NH4-N 曲线
- 与 baseline 对比
- 生成异常解释
- 导出为分析证据
```

---

## 8. Row Object：流程对象完整分析

### 8.1 Node Row Object

选中某一行节点后，展开：

```text
Node Object Panel
├── 节点摘要
├── 模型绑定
├── 上游节点
├── 下游节点
├── 主要组分趋势
├── 质量守恒摘要
├── 参数集
├── 异常时间点
├── 相关事件
└── 可执行动作
```

### 8.2 Edge Row Object

选中某一条边后，展开：

```text
Edge Object Panel
├── 边摘要
├── From / To
├── 流量时间序列
├── 组分负荷时间序列
├── 回流/旁路/排泥类型
├── 对下游节点影响
├── 异常时间段
└── 可执行动作
```

---

## 9. Column Dimension Axis：列作为观察轴

列不只是字段，而是可以转换为观察轴。

### 9.1 Component Axis

点击 `NH4-N` 列后，展开：

- 全节点 NH4-N 分布。
- NH4-N 沿流程图传播路径。
- NH4-N 时间趋势。
- 异常节点排名。
- 与 DO / COD 的相关变化。

### 9.2 Metric Axis

点击 `Mass Error` 列后，展开：

- 质量误差分布。
- 最大误差时间段。
- 误差与模型节点类型关系。
- 是否超出可信阈值。

### 9.3 Scenario Axis

点击 `Plan A` 列后，展开：

- Plan A 相对 baseline 的改善项。
- Plan A 风险项。
- Plan A 受影响节点。
- Plan A 审批建议。

---

## 10. 与流程图的联动

### 10.1 点击流程图节点

系统行为：

```text
1. 表格切换到该节点的 Time × Component 视图。
2. 节点在表格中对应行高亮。
3. 底部趋势图显示该节点关键组分。
4. Cell Portal 显示节点摘要。
```

### 10.2 点击流程图边

系统行为：

```text
1. 表格切换到 Edge × Flow / Load 视图。
2. 高亮上下游节点。
3. 显示该边流量、负荷、来源。
```

### 10.3 点击表格单元格

系统行为：

```text
1. 打开 Result Cell Portal。
2. 流程图高亮该节点/边。
3. 高亮上下游路径。
4. 时间轴定位到对应 time。
5. 趋势图标记该点。
```

### 10.4 拖动时间轴

系统行为：

```text
1. 表格当前切片更新。
2. 流程图热力图更新。
3. 异常标记更新。
4. 当前 Cell Portal 同步时间点。
```

### 10.5 点击列观察轴

系统行为：

```text
1. 流程图按该组分或指标染色。
2. 显示分布、趋势、异常排名。
3. 表格进入该列的 dimension mode。
```

---

## 11. Data Growth Replay：求解过程回放

对于 ODE 结果，Growth Replay 不只是视觉动画，而是基于求解事件日志的回放。

### 11.1 事件类型

| 事件 | 说明 |
|---|---|
| job_submitted | 任务提交 |
| input_validated | 输入通过校验 |
| process_graph_compiled | 流程图转换为计算拓扑 |
| tensor_built | 张量或 ODE 输入构建完成 |
| solver_started | 求解开始 |
| segment_entered | 进入某个时间段 |
| parameter_changed | 参数发生分段变化 |
| warning_emitted | 产生警告 |
| solver_completed | 求解完成 |
| result_persisted | 结果保存 |
| artifact_generated | 生成 artifact |

### 11.2 回放能力

用户可以：

- 回放仿真任务从输入到结果的全过程。
- 查看某个时间段何时进入。
- 查看某个参数变化如何导致状态变化。
- 查看 warning 的产生时间和影响对象。
- 查看结果 artifact 是如何生成的。

---

## 12. Data Space Map：完整态

P3 阶段可以提供完整数据空间地图。

```text
中心：
- 当前流程图 + 当前表格投影

周围维度：
- Time
- Node
- Edge
- Component
- Scenario
- Model
- Parameter
- Quality
- Artifact
- Event
- Agent Insight
```

Data Space Map 用于：

- 系统级分析。
- 复盘。
- 审计。
- Agent 解释。
- 跨方案对比。
- 模型治理。

---

## 13. 数据模型草案

### 13.1 ODEResultSpace

```ts
type ODEResultSpace = {
  schema_version: "ode-result-space.v1";

  result_id: string;
  job_id: string;
  scenario_id: string;
  process_graph_id: string;
  model_run_id: string;

  axes: {
    time: TimeAxis;
    nodes: NodeAxis;
    edges: EdgeAxis;
    components: ComponentAxis;
    metrics: MetricAxis;
    scenarios?: ScenarioAxis;
  };

  tensors: {
    node_values: NodeComponentTimeTensor;
    edge_values: EdgeMetricTimeTensor;
    mass_balance?: MassBalanceTensor;
    volume_balance?: VolumeBalanceTensor;
  };

  projections: {
    table_views: TableProjection[];
    graph_overlays: GraphOverlay[];
    charts: ChartProjection[];
    event_timeline: ResultEvent[];
  };

  quality: ResultQuality;
  provenance: ResultProvenance;
};
```

### 13.2 Axis

```ts
type TimeAxis = {
  unit: "h" | "min" | "s";
  values: number[];
  labels: string[];
  segment_refs?: string[];
};

type NodeAxis = {
  nodes: Array<{
    node_id: string;
    label: string;
    node_type: string;
    model_key?: string;
  }>;
};

type EdgeAxis = {
  edges: Array<{
    edge_id: string;
    source_node_id: string;
    target_node_id: string;
    edge_type: string;
  }>;
};

type ComponentAxis = {
  schema_id: string;
  components: Array<{
    component_key: string;
    label: string;
    unit: string;
    semantic_type: string;
  }>;
};
```

### 13.3 Tensor

```ts
type NodeComponentTimeTensor = {
  shape: ["node", "component", "time"];
  data_ref: string;
  encoding: "json" | "arrow" | "parquet";
  preview?: Array<{
    node_id: string;
    component_key: string;
    time: number;
    value: number;
  }>;
};

type EdgeMetricTimeTensor = {
  shape: ["edge", "metric", "time"];
  data_ref: string;
  encoding: "json" | "arrow" | "parquet";
};
```

### 13.4 Cell Context

```ts
type ResultCellContext = {
  cell_id: string;

  coordinates: {
    object_type: "node" | "edge" | "system";
    object_id: string;
    component_key?: string;
    metric_key?: string;
    time: number;
    scenario_id?: string;
  };

  value: {
    raw: number | string | null;
    display: string;
    unit?: string;
    semantic_type: string;
  };

  state: {
    status: "normal" | "warning" | "error" | "unknown";
    threshold_state?: string;
    confidence?: number;
  };

  source: {
    job_id: string;
    model_run_id: string;
    model_key: string;
    model_version?: string;
    artifact_ref?: string;
  };

  relations: {
    upstream_node_ids: string[];
    downstream_node_ids: string[];
    related_edge_ids: string[];
    related_component_keys: string[];
  };

  actions: string[];
};
```

### 13.5 Result Quality

```ts
type ResultQuality = {
  convergence_status: "converged" | "warning" | "failed" | "unknown";
  solver_method: string;
  final_mass_balance_error?: number;
  final_volume_balance_error?: number;
  warnings: Array<{
    warning_id: string;
    severity: "info" | "warning" | "critical";
    object_type?: "node" | "edge" | "system";
    object_id?: string;
    time?: number;
    message: string;
  }>;
};
```

---

## 14. Artifact 与存储策略

ODE 结果可能非常大，不应全部写入数据库。

### 14.1 推荐策略

| 数据 | 存储 |
|---|---|
| job status | 数据库 |
| summary | 数据库 |
| quality summary | 数据库 |
| model_run | 数据库 |
| artifact index | 数据库 |
| 完整时间序列 | artifact 文件 |
| tensor 数据 | artifact 文件 |
| charts / exports | artifact 文件 |

### 14.2 Artifact 类型

```text
result.json
node_timeseries.csv
edge_timeseries.csv
mass_balance.json
volume_balance.json
charts/*.png
report.md
```

---

## 15. Agent Insight 接入

Agent 不应直接读取无结构 JSON，而应读取 ResultCellContext、ResultQuality、ModelRun、EventTimeline 等结构化上下文。

### 15.1 示例问题

用户点击 `R2 / NH4-N / 8h` 后问：

```text
为什么这里 NH4-N 升高？
```

Agent 可使用：

- 当前值。
- 上游输入。
- 上游边流量。
- DO 与 COD 同时间变化。
- 质量守恒状态。
- segment event。
- 参数变化事件。
- model_run 信息。

输出示例：

```text
R2 在 8h 的 NH4-N 升高主要来自 2-6h 冲击负荷后的上游氨氮输入增加，同时 R2 在 6-8h 的 DO 维持在较低水平，限制了硝化反应速率。质量守恒误差正常，因此该现象更可能由工况变化导致，而不是数值发散。
```

---

## 16. 组件拆分

```text
ODEResultSpace
├── ResultHeader
├── ProcessGraphResultOverlay
│   ├── NodeHeatLayer
│   ├── EdgeFlowLayer
│   ├── UpstreamDownstreamHighlighter
│   └── WarningMarkerLayer
│
├── ResultTimeController
│   ├── TimeSlider
│   ├── SegmentMarkers
│   └── PlaybackControls
│
├── ODEResultTable
│   ├── ViewModeSwitcher
│   ├── NodeComponentSliceView
│   ├── NodeTimeSeriesView
│   ├── EdgeFlowLoadView
│   ├── ScenarioComparisonView
│   ├── QualityDiagnosticsView
│   └── CellRenderer
│
├── ResultCellPortal
│   ├── CurrentValuePanel
│   ├── TrendPanel
│   ├── SourcePanel
│   ├── RelationPanel
│   ├── QualityPanel
│   ├── EventPanel
│   └── ActionPanel
│
├── RowObjectPanel
│   ├── NodeObjectPanel
│   ├── EdgeObjectPanel
│   └── ModelRunPanel
│
├── ColumnDimensionAxis
│   ├── ComponentDistributionView
│   ├── MetricDiagnosticView
│   ├── ScenarioAxisView
│   └── TrendView
│
├── ResultGrowthReplay
│   ├── SolverEventTimeline
│   ├── SegmentReplay
│   ├── WarningReplay
│   └── ArtifactGenerationReplay
│
└── ResultEvidencePanel
```

---

## 17. 状态与视觉规则

### 17.1 单元格状态

| 状态 | 视觉建议 |
|---|---|
| 正常 | 默认文本 |
| 达标 | 绿色角标 |
| 警告 | 黄色边框 |
| 错误 | 红色边框 |
| 超阈值 | 橙色底纹 |
| 缺失 | 灰色斜线 |
| 低置信度 | 虚线边框 |
| 来自 fallback | 紫色角标 |
| 有解释 | 信息图标 |
| 有相关事件 | 时间点图标 |

### 17.2 流程图状态

| 状态 | 视觉建议 |
|---|---|
| 当前选中 | 蓝色高亮 |
| 上游路径 | 青色流向线 |
| 下游影响 | 绿色流向线 |
| 警告节点 | 黄色描边 |
| 错误节点 | 红色描边 |
| 热力值 | 低值蓝色，高值橙红 |
| 质量误差 | 节点角标 |
| segment event | 时间轴 marker |

---

## 18. 关键交互动作

| 动作 | 说明 |
|---|---|
| 选择时间 | 更新时间切片 |
| 选择组分 | 表格和流程图按该组分更新 |
| 点击节点 | 打开节点详情结果 |
| 点击边 | 打开边流量/负荷结果 |
| 点击单元格 | 打开 Cell Portal |
| 高亮上游 | 查看当前值来源路径 |
| 高亮下游 | 查看当前值影响路径 |
| 对比方案 | baseline 与 scenario 并排 |
| 查看质量诊断 | 打开 mass/volume/convergence 视图 |
| 导出证据 | 导出 result summary、chart、artifact |
| Agent 解释 | 根据当前 Cell Context 生成解释 |

---

## 19. 与 SegmentedInputSpace 的关系

SegmentedInputSpace 是仿真前输入空间，ODEResultSpace 是仿真后结果空间。

```text
SegmentedInputSpace
  ↓ 生成 SimulationInput
Simulation Worker
  ↓ 生成 ComputeResult
ODEResultSpace
```

两者应共享：

- ProcessGraph ID。
- Scenario ID。
- Time Axis。
- Segment markers。
- Component schema。
- Model run。
- Cell Portal 思想。
- Row Object / Column Axis 交互。
- Artifact 引用。
- Agent context。

### 19.1 输入到结果的可追溯关系

Result Cell Portal 应能回溯到输入来源：

```text
R2 / NH4-N / 8h
  ← 受 2-6h IN / NH4-N 冲击输入影响
  ← 受 6-10h R2 / DO setpoint 影响
  ← 受 RECYCLE / 40% 回流影响
```

这能让用户从结果异常反查输入设定。

---

## 20. MVP 实施路线

### P0：核心结果分析工作台

| 功能 | 验收标准 |
|---|---|
| Node × Component 当前时间切片 | 可查看当前时间点所有节点主要组分 |
| Time Slider | 拖动时间后表格和流程图同步更新 |
| 流程图节点联动 | 点击节点过滤结果 |
| Cell Portal 基础版 | 显示当前值、单位、时间、节点、来源 |
| 基础趋势图 | 点击单元格显示该值时间趋势 |
| 质量摘要 | 显示 convergence、mass error、warnings |
| Artifact 引用 | 可打开 result artifact |

### P1：关系与诊断增强

| 功能 | 验收标准 |
|---|---|
| Edge × Flow / Load 视图 | 可查看边流量和负荷 |
| 上下游高亮 | 点击单元格可高亮影响路径 |
| Component Axis | 点击组分列可查看分布和异常排名 |
| Mass Balance Diagnostics | 可定位质量误差异常 |
| Scenario Comparison | 可对比 baseline 和 scenario |
| Result Event Timeline | 可查看求解过程事件 |

### P2：解释与证据

| 功能 | 验收标准 |
|---|---|
| Agent Insight | 可基于 Cell Context 生成解释 |
| ModelRun Evidence | 可查看模型版本、参数 hash、输入 hash |
| 导出报告 | 可导出分析证据 Markdown / PDF |
| Result Replay | 可回放 segment 与 warning 的变化 |
| Artifact Gallery | 可管理图表、CSV、JSON 等结果文件 |

### P3：完整数据空间

| 功能 | 验收标准 |
|---|---|
| Data Space Map | 可查看 node/edge/component/time/model/artifact 关系 |
| 多轴对比 | 可同时比较场景、模型、参数 |
| Surface View | 可展示时间 × 节点 × 组分的表面趋势 |
| Agent Copilot | Agent 可在数据空间中辅助解释、定位和建议 |

---

## 21. 验收标准

P0 完成时，系统应满足：

1. 用户可以从仿真 job 打开 ODE 结果工作台。
2. 用户可以看到流程图与结果表格联动。
3. 用户可以通过时间滑块查看不同时间点结果。
4. 用户可以点击节点查看该节点时间序列。
5. 用户可以点击单元格查看当前值、单位、时间、来源。
6. 用户可以查看基础趋势图。
7. 用户可以查看质量摘要，包括收敛状态和质量守恒误差。
8. 用户可以定位警告节点和异常值。
9. 用户可以打开结果 artifact。
10. 所有展示数据都能回溯到 job_id 和 model_run_id。

---

## 22. 主要风险与应对

| 风险 | 说明 | 应对 |
|---|---|---|
| 数据量过大 | 时间点、节点、组分多 | tensor artifact + 表格 projection + 虚拟滚动 |
| 用户迷失 | 流程图、表格、曲线多视图复杂 | 保留流程图、表格、时间轴三重锚点 |
| 结果不可解释 | 只有数值，没有来源 | Cell Context + ModelRun + Event Timeline |
| 图表过多 | 趋势图、热力图、表格冲突 | 默认表格锚点，图表作为局部展开 |
| 流程图热力误导 | 不同组分单位不同 | 按组分归一化，并显示单位和范围 |
| Agent 胡乱解释 | 缺少结构化上下文 | Agent 只能基于 Cell Context / Quality / Event |
| 大结果入库 | 影响性能 | summary 入库，timeseries artifact 化 |

---

## 23. 最终产品判断

ODEResultSpace 不应被定义为“结果表格”，而应被定义为：

```text
AutoWaterSimu 的 ODE 求解结果数据空间。
```

它的价值是：

- 把流程图拓扑与 ODE 数值结果连接起来。
- 把节点、边、组分、时间、场景、模型运行证据组织成可分析空间。
- 让用户从任意单元格进入来源、趋势、上下游关系和质量状态。
- 让仿真结果不仅可视化，而且可解释、可审计、可导出。
- 为未来 Agent 解释、milp 方案校核、NewSystem 审批证据提供基础。

一句话总结：

> **AutoWaterSimu 的 ODE 输出本质上就是一个多维数据空间；流程图是拓扑入口，多维表格是数值入口，Cell Portal 是解释入口。**
